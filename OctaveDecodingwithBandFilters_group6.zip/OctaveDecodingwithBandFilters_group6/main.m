%% LAB P14 - Group 6 - Tyson Skogerboe, Emily Yang, Maili Vu, Chandra Mauli Dubey

%% FOR MORE DETAILED REPORTS
% See 
% LabP14_Exercise4\html\main4_1.html
% LabP14_Exercise4\html\main4_2.html
% LabP14_Exercise5\html\main5_1.html
% LabP14_Exercise5\html\main5_2.html
% LabP14_Exercise5\html\main5_3.html

clear;
close all;
%% Section 4.1 - Windowing Testing
run('LabP14_Exercise4\main4_1.m');      % Run section 4.1

% The width of the passband is inversely related to filter length (L). In
% summary, longer filters lead to higher frequency selectivity.

%% Section 4.2 - Windowing Testing
run('LabP14_Exercise4\main4_2.m');      % Run section 4.2
% For L = 41, the magnitude response shows a clear band centered at ω = 0.25π,
%  indicating that the Hamming BPF successfully passes the desired frequency component.
%  The filter exhibits strong attenuation at the other tested frequencies 
% (0, 0.1π, 0.4π, 0.5π, and 0.75π), with magnitude values near zero, 
% confirming that these lie in the stopband.
%  The Hamming window produces very small stopband ripples (<0.01),
%  consistent with the lab description.
%  The phase response is approximately linear in the passband, 
% as expected for a symmetric FIR filter. 

% From the measured passband widths, we observe that the width of the
% passband is inversely related to the filter length L. When L is
% approximately doubled (e.g., from 41 to 81), the passband width is
% roughly halved. When L is approximately halved (e.g., from 41 to 21),
% the passband width roughly doubles. Thus, longer Hamming FIR filters
% produce narrower passbands (better frequency selectivity), while
% shorter filters produce wider passbands.

%% 4.2(c) Output signal of the length-41 Hamming BPF (by hand summary)
% The input to the L = 41 Hamming BPF is
%   x[n] = 2 + 2*cos(0.1*pi*n + pi/3) + cos(0.25*pi*n - pi/3).
% Using the magnitude and phase from 4.2(a) we have, for this filter:
%   |H(0)|       ≈ 0.00735,  ∠H(0)       ≈ π        (DC term, stopband)
%   |H(0.1π)|    ≈ 0.00735,  ∠H(0.1π)    ≈ -π       (tone 1, stopband)
%   |H(0.25π)|   ≈ 1.0,      ∠H(0.25π)   = φ_c      (tone 2, passband)
%
% For an LTI system with frequency response H(e^{jω}), an input
%   A*cos(ωn + φ)
% produces an output
%   A|H(e^{jω})| * cos(ωn + φ + ∠H(e^{jω})).
%
% Applying this to each term of x[n]:
%   DC term (ω = 0):
%       y0[n] = 2|H(0)|cos(0 + ∠H(0)) ≈ 2*0.00735*cos(π) ≈ -0.0147
%       → a very small negative constant (heavily attenuated).
%
%   Tone 1 (ω = 0.1π):
%       y1[n] = 2|H(0.1π)|cos(0.1π*n + pi/3 + ∠H(0.1π))
%             ≈ 2*0.00735*cos(0.1π*n + (phase)) ≈ 0.0147*cos(0.1π*n + …)
%       → very small amplitude, also in the stopband.
%
%   Tone 2 (ω = 0.25π):
%       y2[n] = |H(0.25π)|cos(0.25π*n - pi/3 + ∠H(0.25π))
%             ≈ cos(0.25π*n - pi/3 + φ_c)
%       → lies at the center of the passband and passes with gain ≈ 1.
%
% Combining the contributions, the output can be written as
%   y[n] = y0[n] + y1[n] + y2[n]
%   y[n] ≈ -0.0147+0.0147 cos⁡(0.1πn-2π/3)+ cos⁡(0.25πn+2π/3)
% Thus, the output is dominated by the 0.25π sinusoid, while the DC and
% 0.1π components are almost completely suppressed because they lie in
% the stopband of the bandpass filter.

%% 4.2(d) Why the L = 41 BPF passes ω = ±0.25π and rejects others
% The frequency response of the length-41 Hamming BPF has a narrow
% passband centered at ω = 0.25π (and, by symmetry, at ω = -0.25π).
% From part (b), the 50% passband edges for L = 41 are approximately
% at ω_low/π ≈ 0.2067 and ω_high/π ≈ 0.294, so only frequencies in
% the interval [0.2067π, 0.294π] are passed with significant gain.
%
% The input signal in part (c) contains components at ω = 0, 0.1π,
% and 0.25π. The components at 0 and 0.1π lie well outside the
% passband and therefore fall in the stopband where |H(e^{jω})| is
% close to zero. These terms are strongly attenuated and appear in
% the output only as very small residuals.
%
% In contrast, the component at ω = 0.25π lies at the center of the
% passband, where |H(e^{j0.25π})| ≈ 1 and the phase response is
% roughly linear. As a result, this sinusoid is passed with almost
% no attenuation and only a phase shift determined by ∠H(e^{j0.25π}).
%
% Because the passband of the L = 41 Hamming BPF is narrow and
% centered at ±0.25π, the filter is able to pass the components at
% ω = ±0.25π while reducing or rejecting all other frequency
% components of the input signal.

%% Section 4.1 & 4.2 Combined Plots
run("LabP14_Exercise4\LabP14_Exercise4.1\main_combined.m");

%% Section 5.1, 5.2, 5.3

%% 5.1 - Edge and center frequencies for Octaves 2-6

% | Octave |  Keys | Lower f (Hz) | Upper f (Hz) | Center f (Hz) | Lower w (rad/sample) | Upper w (rad/sample) | Center w (rad/sample) |
% | -----: | :---: | -----------: | -----------: | ------------: | -------------------: | -------------------: | --------------------: |
% |      2 | 16–27 |    65.406 Hz |   123.471 Hz |     94.439 Hz |             0.051370 |             0.096974 |              0.074172 |
% |      3 | 28–39 |   130.813 Hz |   246.942 Hz |    188.877 Hz |             0.102740 |             0.193948 |              0.148344 |
% |      4 | 40–51 |   261.626 Hz |   493.883 Hz |    377.755 Hz |             0.205480 |             0.387896 |              0.296688 |
% |      5 | 52–63 |   523.251 Hz |   987.767 Hz |    755.509 Hz |             0.410960 |             0.775790 |              0.593375 |
% |      6 | 64–75 |  1046.502 Hz |  1975.533 Hz |   1511.018 Hz |             0.821921 |             1.551580 |              1.186751 |


%% 5.2 - Bandpass Filter design
% Octave 2: L = 250
%
% Octave 3: L = 125
%
% Octave 4: L = 63
%
% Octave 5: L = 31
%
% Octave 6: L = 16

run("LabP14_Exercise5\main5_3.m");      % Run section 5.3 - Includes 5.1 and 5.2

%% 5.3 (d) Validate that output signals have correct magnitude & phase
% After observing the 5.3 (c) figure and confirming the output signals have
% the correct magnitude and phase, the following signals are found to be in
% the designated octaves:
%       220 Hz:  octave 3
%       880 Hz:  octave 5
%       440 Hz:  octave 4
%       1760 Hz: octave 6


%% 5.3 (e) Transient effects at transitions
% Observing the 5.3 (c) figure, the transient effect of each FIR filter
% is directly proportional to the value of L, where the transient grows
% larger as L increases and vice versa
